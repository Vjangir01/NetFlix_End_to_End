# Databricks notebook source
dbutils.widgets.text("weekend", "7")

# COMMAND ----------

dbutils.widgets.text("weekday", "1", "Enter Weekday")
var = int(dbutils.widgets.get("weekday"))

# COMMAND ----------

