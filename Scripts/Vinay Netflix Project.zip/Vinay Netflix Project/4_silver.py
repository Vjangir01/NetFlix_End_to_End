# Databricks notebook source
# MAGIC %md
# MAGIC # Silver Data Transformation 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import *

# COMMAND ----------

df = spark.read.format("Delta")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load("abfss://bronze@netflixprojectvinay.dfs.core.windows.net/netflix_titles")


# COMMAND ----------

df.display()

# COMMAND ----------

df = df.fillna(rescued_data = )

# COMMAND ----------

df1 = spark.read.format("delta")\
    .option("header",True)\
    .option("inferSchema",True)\
    .load(r"abfss://bronze@netflixprojectvinay.dfs.core.windows.net/netflix_titles")
display(df1)

# COMMAND ----------

df = df.withColumn("type_flag", when(col("show_id")==801638890,1).otherwise(0))

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.withColumn("show_id_rnk",dense_rank().over(Window.orderBy(col('show_id').desc())))

# COMMAND ----------

df.display()

# COMMAND ----------

df.createOrReplaceTempView("temp_view")


# COMMAND ----------

df = spark.sql("""
               select * from temp_view

               """)

# COMMAND ----------

df.display()

# COMMAND ----------

df.createOrReplaceGlobalTempView("global_temp_view")
df.display()

# COMMAND ----------

from pyspark.sql.functions import count; df = df.groupBy("show_id").agg(count("*").alias("total_count"))
df.show()

# COMMAND ----------

df.write.format("delta")\
    .mode("overwrite")\
    .option("path", "abfss://silver@netflixprojectvinay.dfs.core.windows.net/netflix_titles")\
    .save()

# COMMAND ----------

