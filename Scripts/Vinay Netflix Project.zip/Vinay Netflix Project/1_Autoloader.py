# Databricks notebook source
# MAGIC %md
# MAGIC ### incremental data loading using AutoLoader

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema if not exists vinayjangir_netflix_catalog.net_schema;

# COMMAND ----------

checkpoint_loc = "abfss://bronze@netflixprojectvinay.dfs.core.windows.net/checkpoint"

# COMMAND ----------

df = spark.readStream\
    .format("cloudFiles")\
    .option("cloudFiles.format", "csv")\
    .option("cloudFiles.schemaLocation",checkpoint_loc )\
    .load("abfss://raw@netflixprojectvinay.dfs.core.windows.net")

# COMMAND ----------

df.display()

# COMMAND ----------

df.writeStream\
    .option("checkpointLocation", checkpoint_loc)\
    .trigger(availableNow=True)\
    .start("abfss://bronze@netflixprojectvinay.dfs.core.windows.net/netflix_titles")

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.withColumn()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.display()

# COMMAND ----------

