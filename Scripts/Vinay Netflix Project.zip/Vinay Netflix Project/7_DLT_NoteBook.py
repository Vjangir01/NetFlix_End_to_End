# Databricks notebook source
# MAGIC %md
# MAGIC ## DLT NoteBook - gold layer

# COMMAND ----------

looktables_rules = {
    "rule1" : "show_id  is not null"
}

# COMMAND ----------

@dlt.table(
    name = "gold_netflixdirectors"
)

@dlt.expect_all_or_drop(looktables_rules)
def myfunc():
    df = spark.readStream("abfss://silver@netflixprojectvinay.dfs.core.windows.net/netflix_directors")
    return df

# COMMAND ----------

@dlt.table(
    name = "gold_netflixcast"
)

def myfunc():
    df = spark.readStream("abfss://silver@netflixprojectvinay.dfs.core.windows.net/netflix_cast")
    return df

# COMMAND ----------

@dlt.table(
    name = "gold_netflixcountries"
)

def myfunc():
    df = spark.readStream("abfss://silver@netflixprojectvinay.dfs.core.windows.net/netflix_countries")
    return df

# COMMAND ----------

@dlt.table(
    name = "gold_netflixcategory"
)

@dlt.expect_or_drop("rule1", "showid is not null")
def myfunc():
    df = spark.readStream("abfss://silver@netflixprojectvinay.dfs.core.windows.net/netflix_category")
    return df